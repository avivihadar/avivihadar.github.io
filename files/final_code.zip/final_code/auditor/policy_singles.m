function [varargout] = policy_singles(params, history, prior_params, recursion, max_recursion, value_dict, model)
	% Function computes the value of the value function based on...
	% params -- vector of auditor parameters [gamma kappa c delta]
	% history -- vector of previous trials (possibly all zero) as [N_white rate_white N_black rate_black]
	% prior -- vector of parameters governing prior distribution of p_b, p_w (shape depends on prior)
	% prior_params -- parameters of alpha_j normal distribution for type1 and type2, respectively, then beta and beta_share

	% Note: The value function code here requires that all the auditors parameters are positive and that delta in (0,1)
	% You also want to ensure that c < delta * gamma to make the problem interesting

	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 1) Define a few variables based on the inputs %%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	gamma = params(1);
	kappa = params(2);
	c = params(3)/2;
	delta = params(4);
	sim = 5000;

	num_xbs = size(prior_params(9:end),2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 2) Get posterior value of investigation     %%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    [e_logit_beta ep_w ep_b prob_disc ] = bayes_severity(sim, prior_params, history, model);
    post_odds = 0;
    bayes_factor = 0;
    posterior_save = e_logit_beta;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 3) Now get maximum recursively  %%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
	% First check if we have solved this problem already
	vd_rel = value_dict(:,size(history,2)+1) == recursion;
	[checked c_loc] = ismember(history, value_dict(vd_rel,1:4*num_xbs), 'rows');
    
    % calculate the value of accusing
    e_accuse = e_logit_beta - kappa;
    % If e_accuse>(-c + delta - kappa) it cant make sense to keep sampling
    alternative = -c + delta - kappa;
    
	if e_accuse > alternative
		[mval option] = max([repmat([-Inf -Inf],1,num_xbs) e_accuse 0]);
        vw_vb = repmat([-Inf -Inf],1,num_xbs);

	% Send a maximum of k additional apps / look max k into the future
	elseif recursion >= max_recursion	
		[mval option] = max([repmat([-Inf -Inf],1,num_xbs) e_accuse 0]);
        vw_vb = repmat([-Inf -Inf],1,num_xbs);
	% Otherwise use the option from the value dict	
	elseif sum(checked) > 0

		tmp_vid = find(vd_rel == 1,c_loc,'first');
		mval = value_dict(tmp_vid(end),4*num_xbs+2);
		option = value_dict(tmp_vid(end),4*num_xbs+3);
        vw_vb = value_dict(tmp_vid(end),4*num_xbs+4:4*num_xbs+7);

	% Otherwise evalulate our options		
	else
		vdb = value_dict;
		tostore = nan(1,2*num_xbs);
		for k = 1:num_xbs
			[esw vdw] = e_send_singles(0, k, params, prior_params, history, ep_w, ep_b, recursion, max_recursion, vdb, model);
			tostore(2*(k-1)+1) = -c + delta*esw;
			[esb vdb] = e_send_singles(1, k, params, prior_params, history, ep_w, ep_b, recursion, max_recursion, vdw, model);	
			tostore(2*(k-1)+2) =  -c + delta*esb;	
        end
        vw_vb = tostore;
		[mval option] = max([tostore e_accuse 0]);
		%value_dict = unique([vdb; history recursion mval option],'rows');
		value_dict = [vdb; history recursion mval option vw_vb];
	end

	varargout = {mval; option; value_dict ; posterior_save ; ep_w; ep_b; prob_disc; vw_vb; post_odds; bayes_factor};
end



