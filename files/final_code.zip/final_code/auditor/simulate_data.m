function [data, Y, D, id] = simulate_data(max_depth, prior_params, model)
    %%%%%% This function geneates the data
    
    % Set seed
    %rng(6583939)

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 1) Declare model      %%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    censored = isequal(model,'censored_norm');
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 2) Construct a sample of jobs using prior DGP      %%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    num_jobs = 500000;

    % Declare number of covariate bins
    cov_params = prior_params(9:end);
    cov_bins = size(cov_params,2);
    
    % parameters
    l=1;
    alpha_0=prior_params(l); l=l+1;
    sigma_alpha=prior_params(l); l=l+1;
    alpha_02=prior_params(l); l=l+1;
    sigma_alpha2=prior_params(l); l=l+1;
    beta_0=prior_params(l); l=l+1;

    sigma_beta=prior_params(l); l=l+1;
    rho=prior_params(l); l=l+1;
    beta_2=prior_params(l); l=l+1;
    
    % jobs random coefficents
    sims = normrnd(0,1,num_jobs,2);
    
    z1=sims(:,1);
    z2=rho*sims(:,1) + sqrt(1-(rho^2))*sims(:,2);
    alpha=alpha_0+sigma_alpha*z1;
    beta=beta_0 + sigma_beta*z2 + beta_2*(z2.^2);
    if censored==1
        beta(beta<0)=0;
    end

    % callback probabilities
    p_w = zeros(num_jobs,cov_bins);
    p_b = zeros(num_jobs,cov_bins);
    logit = @(x) (1+exp(-x)).^-1 ;
    for k=1:cov_bins
        p_w(:,k) = logit(alpha+cov_params(k));
        p_b(:,k) = logit(alpha +cov_params(k) - beta) ;
    end
    
    cb_w = binornd(1,kron(p_w,ones(max_depth/2,1)));
    cb_b = binornd(1,kron(p_b,ones(max_depth/2,1)));
    
    id = [1:1:num_jobs]';
    
    Y_D_w = zeros(num_jobs*max_depth/2,cov_bins,7);
    Y_D_b = zeros(num_jobs*max_depth/2,cov_bins,7);
    for k=1:cov_bins 
        % vars: id, CB, black, p_w, p_b, quality_in 
        Y_D_w(:,k,:) = [ kron(id,ones(max_depth/2,1)) cb_w(:,k) zeros(num_jobs*(max_depth/2),1) kron(p_w(:,k),ones(max_depth/2,1)) kron(p_b(:,k),ones(max_depth/2,1))  ones(num_jobs*max_depth/2,1)*k kron(beta,ones(max_depth/2,1)) ];
        Y_D_b(:,k,:) = [ kron(id,ones(max_depth/2,1)) cb_b(:,k) ones(num_jobs*(max_depth/2),1)  kron(p_w(:,k),ones(max_depth/2,1)) kron(p_b(:,k),ones(max_depth/2,1))  ones(num_jobs*max_depth/2,1)*k kron(beta,ones(max_depth/2,1)) ];
    end
    
    if cov_bins>1
        Y_D_w_new = reshape(Y_D_w,[num_jobs*max_depth,7]);
        Y_D_b_new = reshape(Y_D_b,[num_jobs*max_depth,7]);
    else
        Y_D_w_new = reshape(Y_D_w,[num_jobs*max_depth/2,7]);
        Y_D_b_new = reshape(Y_D_b,[num_jobs*max_depth/2,7]);
        
    end    
    data = [Y_D_w_new ; Y_D_b_new];
    data = sortrows(data, [1 ]);
    
    id = data(:,1);
    Y = data(:,2);
    D = data(:,3);
    
end