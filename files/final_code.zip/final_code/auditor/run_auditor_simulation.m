%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% This program simulates the auditor's decision       %%%
%%% for the paper "Adaptive Correspondence Experiments" %%%
%%% Avivi, Kline, Rose and Walters (2021)     %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
try
   parpool(40);
end

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 1) configurations  %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%

% Set seed
%rng(6583939)

% prior dictionary
prior = containers.Map();
%                         [alpha_0 sigma_alpha alpha_0 sigma_alpha beta_0 sigma_beta rho  beta_2 x_cov ]
prior('censored_norm')     = [-4.922  4.968      -4.922  4.968       -5.035   6.437    0      0       0];

%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 2) set model     %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%
data_set='simulated_beta_censored_norm_pairs0_w_x';
max_depth = 8; % maximum number of apps per job
pairs = 0; % the auditor decides to send a single app
xbs = 2; % number of quality variables

% prior model 
model = 'censored_norm';
simulation=isequal(data_set,'simulation');


%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% 3) Start         %%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%

% simulate the data
if simulation==1
    prior_params = prior(model);
    if xbs>1
        prior_params(end) =  -0.5087;
        prior_params(end+1) = 0.5087;
    end
    
    data_set = sprintf('simulated_beta_%s_pairs%s_w_x.csv', model, num2str(pairs));
    if pairs==1
            [data, Y, D, id] = simulate_data(max_depth, prior_params, model);
    else
            [data, Y, D, id] = simulate_data(max_depth*2, prior_params, model);
    end    
    
    fid = fopen(data_set,'w');
    fclose(fid);

    dlmwrite(data_set, data, 'delimiter', ',', '-append'); 
    data_set = sprintf('simulated_beta_%s_pairs%s_w_x', model, num2str(pairs));

end

% simulate the auditor's decision
for kappa=0.01:0.02:0.19
    
for c=0.00001:0.00005:0.004
    
for num_initial_pairs=0:4 % loop over num_initial_pairs

    num_initial_pairs
    gamma=0
    kappa
    c
    % params = [gamma kappa c delta]
    params = [gamma kappa c 1];	

    auditor_decision(num_initial_pairs, max_depth, pairs, xbs, params, data_set, prior(model), model)
end
end
end

  