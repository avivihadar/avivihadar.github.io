function [varargout] = e_send_singles(b, k, params, prior_params, history, ep_w, ep_b, recursion, max_recursion, value_dict, model)
	% Function computes the expected value function
	% b is an indicator for whether not the application sent was black
	% k is an index of the type of the application (i.e., the covariate bin)
	% params -- vector of auditor parameters [gamma kappa c delta]
	% history -- vector of previous trials (possibly all zero) as [N_white rate_white N_black rate_black]
	% ep_w, ep_b, expected probability of acceptances based on updated prior 
	% prior -- vector of parameters governing prior distribution of p_b, p_w (shape depends on prior)
	% prior_params -- parameters of alpha_j normal distribution for type1 and type2, respectively

	% First increment recursion counter for maximum depth  
	recursion = recursion + 1;

	% Column offset for types in history:
	kc = (k-1)*4;
	if b == 0
		% With prob ep_w, application is accepted
		new_hist = history;
		new_hist(1+kc) = new_hist(1+kc) + 1;
		new_hist(2+kc) = (history(1+kc)*history(2+kc) + 1) / (history(1+kc) + 1);
		[t c vd] = policy_singles(params, new_hist, prior_params, recursion, max_recursion, value_dict, model);
		val = t*ep_w(k);

		% With prob 1-ep_w, application is rejected
		new_hist = history;
		new_hist(1+kc) = new_hist(1+kc) + 1;
		new_hist(2+kc) = (history(1+kc)*history(2+kc)) / (history(1+kc) + 1);
		[t c value_dict] = policy_singles(params, new_hist, prior_params, recursion, max_recursion, vd, model);
		val = val + t*(1-ep_w(k));

		varargout = {val; value_dict};
	else
		% With prob ep_b, application is accepted
		new_hist = history;
		new_hist(3+kc) = new_hist(3+kc) + 1;
		new_hist(4+kc) = (history(3+kc)*history(4+kc) + 1) / (history(3+kc) + 1);
		[t c vd] = policy_singles(params, new_hist, prior_params, recursion, max_recursion, value_dict, model);
		val = t*ep_b(k);

		% With prob 1-ep_b, application is rejected
		new_hist = history;
		new_hist(3+kc) = new_hist(3+kc) + 1;
		new_hist(4+kc) = (history(3+kc)*history(4+kc)) / (history(3+kc) + 1);
		[t c value_dict] = policy_singles(params, new_hist, prior_params, recursion, max_recursion, vd, model);
		val = val + t*(1-ep_b(k));

		varargout = {val; value_dict};
	end


