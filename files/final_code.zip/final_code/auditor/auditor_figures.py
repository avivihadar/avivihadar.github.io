import pandas as pd
import os
import matplotlib.pyplot as plt
import numpy as np
from scipy.special import logit, expit
from statistics import mean

## change to your local directory
os.chdir('YOUR_DIRECTORY')

########################
##### functions  #######
########################

def fix_col_names(df):
    for col in df.columns:
        df.rename(columns = {col : col.strip()}, inplace=True)
    return df

def call_file_quality(file_name):
    df = pd.read_csv('results/policy/{}.csv'.format(file_name))
    df = fix_col_names(df)

    for col in df.columns:
        df[col] = pd.to_numeric(df[col])

    if "_wo_x_" in file_name:
        df['hist_type'] = "(" + round(df['R_w'] * df['N_w']).astype(int).astype(str) + "," + round(df['R_b'] * df['N_b']).astype(
            int).astype(str) + ")"

        df['hist_type_design'] = "(" + round(df['N_w']).astype(int).astype(str) + "," + round(df['N_b']).astype(
            int).astype(str) + ")"
    else:
        df['hist_type'] = "(" + round(df['R_w_l'] * df['N_w_l']).astype(int).astype(str) + "," + \
                          round(df['R_b_l'] * df['N_b_l']).astype(int).astype(str) + "," + \
                          round(df['R_w_h'] * df['N_w_h']).astype(int).astype(str) + "," + \
                          round(df['R_b_h'] * df['N_b_h']).astype(int).astype(str) + ")"

        df['hist_type_design'] = "(" + round(df['N_w_l'] ).astype(int).astype(str) + "," + \
                          round(df['N_b_l'] ).astype(int).astype(str) + "," + \
                          round(df['N_w_h'] ).astype(int).astype(str) + "," + \
                          round(df['N_b_h'] ).astype(int).astype(str) + ")"

    # df['hist_id'] =  df['hist_type_design'] + "\n" +  df['hist_type']
    df['hist_id'] = "Sent: " +  df['hist_type_design'] + "\n" + "CB: " +  df['hist_type']

    df = df.sort_values(by=['posterior'], ascending=False)

    return df


##########################
## final data functions ##
##########################

# create the general resuts gzip files and dictionary
def save_results_gzip(files, dict_columns, kappa_range, opt=False):
    for file_name_raw in files:
        #print(file_name_raw)
        if "pairs1" in file_name_raw:
            pairs = 1
        elif "pairs0" in file_name_raw:
            pairs = 0
        else:
            raise Exception("Issue with pairs, file {}".format(file_name_raw))

        if "_wo_x_" in file_name_raw:
            with_x = 0
        else:
            with_x = 1

        # you can ignore the part of "optimal_exante". These are leftovers from old versions
        optimal_exante=""
        optimal_exante2 = ""
        if opt==True:
            optimal_exante = "_opt"+'\x01'
            optimal_exante2 = "_opt"

        for kappa in np.arange(kappa_range[0], kappa_range[1], 0.02):
            kappa = round(kappa, 2)
            for c in  np.arange(0.00001, 0.004, 0.00005):
            #for c in np.arange(0.00101, 0.004, 0.00005):

                c = round(round(c, 5)*1000,2)
                #print(c)

                if c>=10:
                    c_name = str(round(c/10,2))+"00000e-02"
                elif (c<10) & (c>=1) :
                    #c_name = str(c) + "00000e-03"
                    c_name = str(c) + "0000e-03"
                elif (c<1) & (c>=0.1) :
                    c_name = str(round(c*10,2)) + "00000e-04"
                elif (c<0.1) & (c>=0.01) :
                    c_name = str(round(c*100,2)) + "00000e-05"

                #print(c_name)
                if opt==True:
                    start = 4
                else:
                    start = 0
                for i in range(start, 5):  # loop on initial pairs

                    ## (i) call final histories df
                    df_final = pd.DataFrame(columns=dict_columns['with_x_{}'.format(with_x)])

                    for j in range(i, 9):  # loop of stage
                        file_name = file_name_raw + "8depth_{}pairs_censored_norm_{}_initpairs{}_kappa{}_c{}".format(
                            pairs, j, i, kappa, c_name)+ optimal_exante
                        print(c)
                        print(file_name)

                        try:
                            df = call_file_quality(file_name)
                            print("\n \n called file {}".format(file_name))
                        except:
                            print("issue with: {}".format(file_name))
                            #break
                            continue

                        ## (ii) keep only final histories
                        df.action.value_counts()
                        if with_x == 0:
                            df_aux = df[df.action >= 3]
                        elif with_x == 1:
                            df_aux = df[df.action >= 5]

                        df_final = df_final.append(df_aux)

                    # check it was built correctly..
                    assert len(df_final) == 500000

                    ## (iv) generate accused variable
                    df_final['ind'] = (df_final['posterior'] > kappa).astype(int)
                    if with_x == 0:
                        df_final['accused'] = (df_final['action'] == 3).astype(int)
                    else:
                        df_final['accused'] = (df_final['action'] == 5).astype(int)
                    # test that Skynet works correctly..
                    assert all(df_final['ind'] == df_final['accused'])

                    ## (v) create indicator for discriminators
                    df_final['T'] = (df_final['beta'].abs() > 0).astype(int)
                    for tresh in [0.5, 0.75, 0.9]:
                        tt = int(tresh * 100)
                        df_final['T_{}'.format(tt)] = (
                                    df_final[df_final['beta'] > 0]['beta'].abs() > df_final[df_final['beta'] > 0][
                                'beta'].abs().quantile(q=tresh)).astype(int)

                    df_final['beta_pct'] = df_final['beta'].abs().rank(pct=True, method='max')

                    ## (vi) save final results

                    df_final.to_csv('results/tmp/pairs{}_wx{}_initpairs{}_kappa{}_c{}{}.csv.gz'.format(pairs, with_x, i, kappa,c, optimal_exante2),
                                    compression='gzip')

### create stats of performance
def preformance_stats(possible_files, kappa_range, c_range, opt=False):
    dict_stats = {}

    optimal_exante2 = ""
    if opt == True:
        optimal_exante2="_opt"

    for df_name in possible_files:
        for i in range(0, 5):  # number of initial pairs
            my_list = []
            for kappa in np.arange(kappa_range[0], kappa_range[1], 0.02):
                kappa = round(kappa, 2)

                for c in np.arange(c_range[0], c_range[1], 0.00005):
                    c = round(round(c, 5) * 1000, 2)

                    print('{}_initpairs{}_kappa{}_c{}{}.csv.gz'.format(df_name, i, kappa,c, optimal_exante2))
                    # df_final = df_dict_firms['{}_initpairs{}_kappa{}'.format(df_name, i, kappa)]
                    try:
                        df_final = pd.read_csv('results/tmp/{}_initpairs{}_kappa{}_c{}{}.csv.gz'.format(df_name, i, kappa,c, optimal_exante2),compression='gzip')
                    except:
                        print('issue with {}_initpairs{}_kappa{}_c{}{}.csv.gz'.format(df_name, i, kappa,c, optimal_exante2))
                        continue

                    my_dict = {}
                    my_dict['kappa'] = kappa
                    my_dict['initial_pairs'] = i
                    my_dict['c'] = (c/1000)/2
                    my_dict['shr_investigated'] = mean(df_final['ind'])

                    my_dict['shr_not_investigated_given_not_disc'] =  mean(df_final['ind'][df_final['beta'] == 0]==0)

                    my_dict['shr_of_discriminators'] = mean(df_final['beta'] > 0)
                    # my_dict['shr_of_discriminators_50'] = mean(df_final['T_50'])
                    # my_dict['shr_of_discriminators_75'] = mean(df_final['T_75'])
                    # my_dict['shr_of_discriminators_90'] = mean(df_final['T_90'])

                    # number of apps
                    if df_name == 'pairs1_wx0':
                        my_dict['N_apps'] = sum(df_final['N_w'] + df_final['N_b'])
                        my_dict['av_apps_per_firm'] = mean(df_final['N_w'] + df_final['N_b'])

                    else:
                        my_dict['N_apps'] = sum(
                            df_final['N_w_l'] + df_final['N_w_h'] + df_final['N_b_l'] + df_final['N_b_h'])
                        my_dict['av_apps_per_firm'] = mean(
                            df_final['N_w_l'] + df_final['N_w_h'] + df_final['N_b_l'] + df_final['N_b_h'])

                    # accusing stats
                    my_dict['accuse_discriminators_0'] = mean(df_final['ind'][df_final['T'] == 1])
                    my_dict['accuse_non_discriminator_0'] = mean(df_final['ind'][df_final['T'] == 0])
                    my_dict['notaccuse_non_discriminator_0'] = mean(1 - df_final['ind'][df_final['T'] == 0])


                    # discriminators with p_w-pb >0.5
                    df_final['pw_pb'] = 0.5*(df_final['p_w_l']- df_final['p_b_l']) + 0.5*(df_final['p_w_h']- df_final['p_b_h'] )
                    df_final['pw_pb_minus_kappa'] = df_final['pw_pb'] - kappa
                    if (df_final['ind']==1).sum()>0:
                        my_dict['av_loss'] = mean(df_final['pw_pb_minus_kappa'][df_final['ind']==1])
                    else:
                        my_dict['av_loss'] = 0

                    df_final['ex_post_value'] = -1*(my_dict['c'])*(df_final['N_w_l'] + df_final['N_w_h'] +
                                                             df_final['N_b_l'] + df_final['N_b_h']) + \
                                                df_final['pw_pb_minus_kappa']*df_final['ind']

                    my_dict['ex_post_value'] = mean(df_final['ex_post_value'])

                    my_dict['90pc_pw_pb_discriminators'] = df_final['pw_pb'][df_final['beta']!=0].quantile(q=0.90)
                    df_final['big_discrimination'] = (df_final['pw_pb']>= my_dict['90pc_pw_pb_discriminators'] ).astype(int)
                    my_dict['share_big_discrimination'] = mean(df_final['big_discrimination'])
                    my_dict['share_big_discrimination_accused'] = mean( df_final['ind'][df_final['big_discrimination'] ==1] )


                    # add imputed number of jobs
                    try:
                        my_dict['imputed_jobs_4000apps'] = 4000 / my_dict['av_apps_per_firm']
                    except:
                        my_dict['imputed_jobs_4000apps'] = None
                    my_dict['imputed_numapps_500firms'] = my_dict['av_apps_per_firm'] * 500

                    try:
                        my_dict['imputed_accused0_4000apps'] = my_dict['imputed_jobs_4000apps'] * my_dict[
                            'accuse_discriminators_0'] * my_dict['shr_of_discriminators']
                    except:
                        my_dict['imputed_accused0_4000apps'] = 0

                    try:
                        my_dict['num_discriminators_pw_pb_50'] =  my_dict['imputed_jobs_4000apps'] *  my_dict[
                            'share_big_discrimination']*my_dict['share_big_discrimination_accused']
                    except:
                        my_dict['num_discriminators_pw_pb_50'] = None

                    try:
                        my_dict['imputed_notaccused_not_disc0_4000apps'] = my_dict['imputed_jobs_4000apps'] * \
                            my_dict['notaccuse_non_discriminator_0'] * (1 - my_dict['shr_of_discriminators'])
                    except:
                        tt=0
                        my_dict['imputed_accused{}_4000apps'.format(tt)] = 0

                    # pw- pb | acccused
                    if (df_final['ind']==1).sum()>0:
                        my_dict['pw_pb_accused'] = mean(df_final['pw_pb'][df_final['ind']==1])

                        my_dict['num_disc_pw_pb_new'] = my_dict['imputed_accused0_4000apps'] * my_dict['pw_pb_accused']
                    else:
                        my_dict['pw_pb_accused'] = None
                        my_dict['num_disc_pw_pb_new'] = None
                    # final stats
                    my_list.append(my_dict)

            # final results for initial pairs ==i
            true_false_df = pd.DataFrame(my_list)
            # save it in dictionary
            dict_stats['{}_init_pairs_{}{}'.format(df_name, i, optimal_exante2)] = true_false_df

            # save (for the future)
            true_false_df.to_csv('results/policy/c_kappa_{}_init_pairs_{}{}.csv'.format(df_name, i, optimal_exante2))

    return dict_stats



if __name__ == "__main__":

    ########################
    #### Configurations  ###
    ########################
    print('configurations...')

    files = ["new_policy_firms_simulated_beta_censored_norm_pairs0_w_x_"]
    dict_columns={}

    file_name = "new_policy_firms_simulated_beta_censored_norm_pairs0_w_x_8depth_0pairs_censored_norm_0_initpairs0_kappa0.16_c3.900000e-02"

    df_aux = pd.read_csv('results/policy/{}.csv'.format(file_name))
    fix_col_names(df_aux)
    columns = df_aux.columns

    dict_columns['with_x_1'] = df_aux.columns

    kappa_range= (0.01, 0.19)
    c_range= (0.00001, 0.004)
    possible_files = ['pairs0_wx1']

    ### flags ###
    create_zip = 0
    create_stats = 0
    stats_to_dict = 1
    figures = 1

    ####################################
    ### (1) Save results in zip files ##
    ####################################

    # create the general results gzip files. run this part only ones.
    df_dict_firms = {}
    if create_zip==1:
        print('creating zips...')
        print('kappa from {} to {}'.format(kappa_range[0], kappa_range[1]))

        save_results_gzip(files, dict_columns, kappa_range)


    ####################################
    ### (2) Create preformance    ######
    ####################################

    # create stats of performance. run only ones, it saves the results in csv files
    if create_stats==1:
        print('creating stats...')
        df_dict_firms={}
        dict_stats = preformance_stats(possible_files, kappa_range, c_range)

    ###################################################
    ### (3) if the csv files were already saved  ######
    ###################################################

    # start here if you have already created the csv stats files
    if stats_to_dict==1:
        print('stats to dict...')
        #df_dict_firms= {}
        dict_stats = {}
        for df_name in possible_files:
            for i in range(5):
                df = pd.read_csv('results/policy/c_kappa_{}_init_pairs_{}.csv'.format(df_name, i))
                dict_stats['{}_init_pairs_{}'.format(df_name, i)] = df


    ###########################
    ### (4) create figures  ###
    ###########################

    if figures==1:
        print('Creating figures...')

        #############################################################################
        ## (i) Holding the investigation rate as constant (fig 3 in the paper)    ###
        #############################################################################
        invest_range = (0.055, 0.06)

        # option (1) without optimal ex ante
        def constant_investigation_rate(df_firms, invest_range):
            fig, ax1 = plt.subplots()

            ## configurations ##
            label = 'Apps per job'

            # ax1.set_xlabel('Share discriminators investigated')
            ax1.set_xlabel(' Pr(investigated | $ \\beta_j>0 $ )')
            ax1.set_ylabel(label)
            plt.grid(axis='y', alpha=0.4)

            # the figure!
            i = 0
            df = df_firms['pairs0_wx1_init_pairs_{}'.format(i)]
            df = df [(df['shr_investigated']>=invest_range[0]) & (df['shr_investigated']<=invest_range[1])]

            plt.plot(df['accuse_discriminators_0'], df['av_apps_per_firm'], 'o',
                     color='blue', alpha=0.6, label="{} pairs".format(i))

            i = 1
            df = df_firms['pairs0_wx1_init_pairs_{}'.format(i)]
            df = df [(df['shr_investigated']>=invest_range[0]) & (df['shr_investigated']<=invest_range[1])]

            plt.plot(df['accuse_discriminators_0'], df['av_apps_per_firm'], 'o',
                     color='red', alpha=0.6, label="{} pairs".format(i))

            i = 2
            df = df_firms['pairs0_wx1_init_pairs_{}'.format(i)]
            df = df [(df['shr_investigated']>=invest_range[0]) & (df['shr_investigated']<=invest_range[1])]

            plt.plot(df['accuse_discriminators_0'], df['av_apps_per_firm'], 'o',
                     color='green', alpha=0.6, label="{} pairs".format(i))

            i = 3
            df = df_firms['pairs0_wx1_init_pairs_{}'.format(i)]
            df = df [(df['shr_investigated']>=invest_range[0]) & (df['shr_investigated']<=invest_range[1])]

            plt.plot(df['accuse_discriminators_0'], df['av_apps_per_firm'], 'o',
                     color='purple', alpha=0.6, label="{} pairs".format(i))

            i = 4
            df = df_firms['pairs0_wx1_init_pairs_{}'.format(i)]
            df = df [(df['shr_investigated']>=invest_range[0]) & (df['shr_investigated']<=invest_range[1])]

            plt.plot(df['accuse_discriminators_0'], df['av_apps_per_firm'], 'o',
                     color='orange', alpha=0.6, label="{} pairs".format(i))


            plt.legend(loc='best', markerscale=1)
            plt.tight_layout()
            plt.savefig('figures/investigation_rate_fixed_{}_{}.png'.format(invest_range[0], invest_range[1]))

            plt.show()
            plt.clf()
            plt.close('all')

        constant_investigation_rate(dict_stats, invest_range)

        #########################################################################################
        ## (ii) Holding the share of discriminators accused as constant (fig 4 in the paper)  ###
        #########################################################################################

        def constant_dic_accused_specificity(df_firms, disc_range):
            fig, ax1 = plt.subplots()

            ## configurations ##
            label = 'Apps per job'

            ax1.set_xlabel(' Pr(not investigated | $ \\beta_j=0 $ ) ')
            ax1.set_ylabel(label)
            plt.grid(axis='y', alpha=0.4)

            # the figure!
            i = 0
            df = df_firms['pairs0_wx1_init_pairs_{}'.format(i)]
            df = df [(df['accuse_discriminators_0']>=disc_range[0]) & (df['accuse_discriminators_0']<=disc_range[1])]

            plt.plot(df['notaccuse_non_discriminator_0'], df['av_apps_per_firm'], 'o',
                     color='blue', alpha=0.6, label="{} pairs".format(i))

            i = 1
            df = df_firms['pairs0_wx1_init_pairs_{}'.format(i)]
            df = df [(df['accuse_discriminators_0']>=disc_range[0]) & (df['accuse_discriminators_0']<=disc_range[1])]

            plt.plot(df['notaccuse_non_discriminator_0'], df['av_apps_per_firm'], 'o',
                     color='red', alpha=0.6, label="{} pairs".format(i))

            i = 2
            df = df_firms['pairs0_wx1_init_pairs_{}'.format(i)]
            df = df [(df['accuse_discriminators_0']>=disc_range[0]) & (df['accuse_discriminators_0']<=disc_range[1])]

            plt.plot(df['notaccuse_non_discriminator_0'], df['av_apps_per_firm'], 'o',
                     color='green', alpha=0.6, label="{} pairs".format(i))

            i = 3
            df = df_firms['pairs0_wx1_init_pairs_{}'.format(i)]
            df = df [(df['notaccuse_non_discriminator_0']>=disc_range[0]) & (df['accuse_discriminators_0']<=disc_range[1])]

            plt.plot(df['notaccuse_non_discriminator_0'], df['av_apps_per_firm'], 'o',
                     color='purple', alpha=0.6, label="{} pairs".format(i))

            i = 4
            df = df_firms['pairs0_wx1_init_pairs_{}'.format(i)]
            df = df [(df['accuse_discriminators_0']>=disc_range[0]) & (df['accuse_discriminators_0']<=disc_range[1])]

            plt.plot(df['notaccuse_non_discriminator_0'], df['av_apps_per_firm'], 'o',
                     color='orange', alpha=0.6, label="{} pairs".format(i))

            # i = 4
            # df = df_firms['pairs0_wx1_init_pairs_{}_opt'.format(i)]
            # df = df [(df['accuse_discriminators_0']>=disc_range[0]) & (df['accuse_discriminators_0']<=disc_range[1])]
            #
            # plt.plot(df['notaccuse_non_discriminator_0'], df['av_apps_per_firm'], 'o',
            #          color='pink', alpha=0.6, label="{} pairs (optimal)".format(i))


            plt.legend(loc='best', markerscale=1)
            plt.tight_layout()
            plt.savefig('figures/fig4_share_disc_accused_fixed_{}_{}.png'.format(disc_range[0], disc_range[1]))

            plt.show()
            plt.clf()
            plt.close('all')

        disc_range = (0.139, 0.145)
        constant_dic_accused_specificity(dict_stats, disc_range)

        ####################################################################
        ## (iii) Catching the worst discriminators (fig 5 in the paper)  ###
        ####################################################################

        ## density of pw - pb by accusation status
        def hist_pw_pb_density( i, kappa, c):
            fig, ax1 = plt.subplots()

            kappa = round(kappa, 2)
            c = round(round(c, 5) * 1000, 2)
            print('pairs0_wx1_initpairs{}_kappa{}_c{}.csv.gz'.format( i, kappa,c))
            df = pd.read_csv('results/tmp/pairs0_wx1_initpairs{}_kappa{}_c{}.csv.gz'.format( i, kappa,c),compression='gzip')

            df['av_pw_minus_pb'] = 0.5 * (df['p_w_l'] - df['p_b_l']) + 0.5 * (df['p_w_h'] - df['p_b_h'])

            df_accused = df[df['ind'] == 1]['av_pw_minus_pb']
            df_giveup = df[df['ind'] == 0]['av_pw_minus_pb']

            heights_ac, bins_ac = np.histogram(df_accused, bins=25)

            # fix the first bin to include only 0
            min_val = round(df_accused[df_accused!=0].min(), 6)
            bins_ac = np.sort(np.append(bins_ac,[min_val]))
            num_0 = len(df_accused[df_accused==0])
            num_0_plus = len(df_accused[(df_accused>=bins_ac[1]) & (df_accused<bins_ac[2])])
            heights_ac = np.append([num_0, num_0_plus], heights_ac[1:])

            heights_ac = heights_ac / sum(heights_ac)

            heights_gu, bins_gu = np.histogram(df_giveup, bins=25)

            # fix the first bin to include only 0
            min_val = df_giveup[df_giveup!=0].min()
            bins_gu = np.sort(np.append(bins_gu,[min_val]))
            num_0 = len(df_giveup[df_giveup==0])
            num_0_plus = len(df_giveup[(df_giveup>=bins_gu[1]) & (df_giveup<bins_gu[2])])
            heights_gu = np.append([num_0, num_0_plus], heights_gu[1:])

            heights_gu = heights_gu / sum(heights_gu)

            # the figure
            w_ac = [(bins_ac[j+1] - bins_ac[j])  - 0.005 for j in range(len(bins_ac)-1) ]
            #w_ac = np.append(w_ac[0], [ x - 0.0001 for x in w_ac[1:]])
            ax1.bar(bins_ac[1:-1], heights_ac[1:], width=w_ac[1:], color='#0504aa',
                     alpha=0.4,  label="Investigated")
            plt.plot(bins_ac[0], heights_ac[0], 'o',
                     color='#0504aa', alpha=0.4)

            w_gu = [(bins_gu[j+1] - bins_gu[j])- 0.005   for j in range(len(bins_gu)-1) ]
            #w_gu = np.append(w_gu[0], [x - 0.0001 for x in w_gu[1:]])

            ax1.bar(bins_gu[1:-1], heights_gu[1:], width=w_gu[1:], color='red',
                     alpha=0.4,  label="Not investigated")
            plt.plot(bins_gu[0], heights_gu[0], 'o',
                     color='red', alpha=0.4)

            ax1.set_xlabel('Average $ p_{w} - p_{b} $')
            ax1.set_ylabel('Probability')

            ax1.tick_params(axis='y')

            plt.grid(axis='y', alpha=0.75)
            plt.legend(loc='best', markerscale=1)

            plt.savefig('figures/hist_pw_pb_init{}_kappa{}_c{}.png'.format(i, kappa,c))
            #plt.show()
            plt.clf()
            plt.close('all')

        hist_pw_pb_density(i=0, kappa=0.13, c=0.000105)


        ##############################################################
        ## (iv) Policy function (figs 1,2 and 1A in the paper) #######
        ##############################################################
        def call_file_quality2(file_name, n):

            df = pd.read_csv('results/policy/{}.csv'.format(file_name))
            df = fix_col_names(df)

            for col in df.columns:
                df[col] = pd.to_numeric(df[col])


            df['hist_type'] = "(" + round(df['R_w_l'] * df['N_w_l']).astype(int).astype(str) + "," + \
                              round(df['R_b_l'] * df['N_b_l']).astype(int).astype(str) + "," + \
                              round(df['R_w_h'] * df['N_w_h']).astype(int).astype(str) + "," + \
                              round(df['R_b_h'] * df['N_b_h']).astype(int).astype(str) + ")"

            df['hist_type_design'] = "(" + round(df['N_w_l'] ).astype(int).astype(str) + "," + \
                              round(df['N_b_l'] ).astype(int).astype(str) + "," + \
                              round(df['N_w_h'] ).astype(int).astype(str) + "," + \
                              round(df['N_b_h'] ).astype(int).astype(str) + ")"

            # df['hist_id'] =  df['hist_type_design'] + "\n" +  df['hist_type']
            df['hist_id_old'] = "Sent: " +  df['hist_type_design'] + "\n" + "CB: " +  df['hist_type']
            df['hist_id'] = round(df['R_w_l']* df['N_w_l']).astype(int).astype(str) + "/" \
                            + round(df['N_w_l']).astype(int).astype(str) + "\n" + \
                            round(df['R_b_l']* df['N_b_l']).astype(int).astype(str) + "/" + \
                            round(df['N_b_l']).astype(int).astype(str) + "\n" + \
                            round(df['R_w_h']* df['N_w_h']).astype(int).astype(str) + "/" +\
                            round(df['N_w_h']).astype(int).astype(str) + "\n" + \
                            round(df['R_b_h']* df['N_b_h']).astype(int).astype(str) + "/" +\
                            round(df['N_b_h']).astype(int).astype(str) + "\n"

            df['hist_short'] = "(" + round(df['R_w_l'] * df['N_w_l'] + df['R_w_h'] * df['N_w_h']).astype(int).astype(str) + "," + \
                              round(df['R_b_l'] * df['N_b_l'] + df['R_b_h'] * df['N_b_h']).astype(int).astype(str)  + ")"


            if "policy_firms" in file_name:
                df['beta'] = logit(pd.to_numeric(df['p_w_h'])) - logit(pd.to_numeric(df['p_b_h']))
                # df['beta_2'] = logit(pd.to_numeric(df['p_w_l'])) - logit(pd.to_numeric(df['p_b_l']))


            df = df.sort_values(by=['posterior'], ascending=False)

            return df


        def fig_qulity_by_apps_kappa(df_final,i, kappa, c):
            fig, ax1 = plt.subplots()
            label = 'Value'
            ax1.set_xlabel('Histories')
            ax1.set_ylabel(label)
            plt.grid(axis='y', alpha=0.4)

            df = df_final

            print(df['hist_id'])
            lables = df['hist_id'].values
            print(lables)
            x = np.arange(len(lables))

            width = 0.2
            if i!=8:
                ax1.bar(x-1.5*width, df['V_w_l'],
                            color='blue', alpha=0.6, width=width, label="Value send LQ white")
                ax1.bar(x-0.5*width, df['V_b_l'],
                            color='green', alpha=0.6, width=width, label="Value send LQ black")

                ax1.bar(x+0.5*width, df['V_w_h'],
                            color='purple', alpha=0.6, width=width, label="Value send HQ white")

                ax1.bar(x+1.5*width, df['V_b_h'],
                            color='skyblue', alpha=0.6, width=width, label="Value send HQ black")
            else:
                ax1.set_ylabel(" $ E[ p_w - p_b |H_n] $")
                ax1.bar(df['hist_id'], df['posterior'],
                        color='blue', alpha=0.6, width=3*width, label=" $ E[p_w - p_b|H_n] $")

            for k in range(len(x)):
                if df['action'].loc[df['hist_id']==lables[k]].values[0]==1:
                    ax1.bar(x[k]-1.5*width, df['V_w_l'].loc[df['hist_id']==lables[k]],
                                 width=width,fill=False, linewidth =2)
                elif df['action'].loc[df['hist_id']==lables[k]].values[0]==2:
                    ax1.bar(x[k]-0.5*width, df['V_b_l'].loc[df['hist_id']==lables[k]],
                                 width=width,fill=False, linewidth =2)
                elif df['action'].loc[df['hist_id']==lables[k]].values[0]==3:
                    ax1.bar(x[k]+0.5*width, df['V_w_h'].loc[df['hist_id']==lables[k]],
                                 width=width,fill=False, linewidth =2)
                elif df['action'].loc[df['hist_id']==lables[k]].values[0]==4:
                    ax1.bar(x[k]+1.5*width, df['V_b_h'].loc[df['hist_id']==lables[k]],
                                 width=width,fill=False, linewidth =2)

            if i != 8:
                ax1.scatter(df['hist_id'], df['val_accuse'],
                            color='red', alpha=0.9, marker="x", label="Value investigate")
                ax1.axhline(y=0, color='black', linestyle='--', label='Value give-up')
            else:
                ax1.axhline(y=kappa, color='red', linestyle='--', label='$ \kappa $')
            if i==1:
                ll = 0.034
            elif i==2:
                ll=0.049
            elif i==3:
                # prev 0.0584
                ll= 0.05835
            elif i==4:
                ll=0.05996
            elif i==5:
                ll=0.0699
            elif i==6:
                ll=0.075
            elif i==7:
                # prev 0.08158
                ll=0.08157
            elif i==8:
                # prev 0.0576311
                ll=0.0576309

            lx = 0.05
            if i==1:
                lx=0.02
            elif i==7:
                lx = 0.08
            elif (i==3) | (i==4) | (i==8):
                lx = 0.22

            if len(x)>11:
                plt.xticks(fontsize=7)
                y_lim = ax1.get_ylim()
                x_lim = plt.xlim()
                ax1.text(x_lim[0]-lx, y_lim[0]-ll, 'LQW\nLQB\nHQW\nHQB',fontsize=7 )
            elif len(x)>17:
                plt.xticks(fontsize=6.5)
                y_lim = ax1.get_ylim()
                x_lim = plt.xlim()
                ax1.text(x_lim[0]-lx , y_lim[0]-ll, 'LQW\nLQB\nHQW\nHQB', fontsize=6.5)
            elif len(x)>20:
                plt.xticks(fontsize=6)
                y_lim = ax1.get_ylim()
                x_lim = plt.xlim()
                ax1.text(x_lim[0]-lx , y_lim[0] -ll, 'LQW\nLQB\nHQW\nHQB', fontsize=6)

            elif i==8:
                plt.xticks(fontsize=7)
                y_lim = ax1.get_ylim()
                x_lim = plt.xlim()
                ax1.text(x_lim[0]-lx , y_lim[0]-ll, 'LQW\nLQB\nHQW\nHQB', fontsize=7)
            else:

                y_lim = ax1.get_ylim()
                x_lim = plt.xlim()
                ax1.text(x_lim[0]-lx, y_lim[0]-ll, 'LQW\nLQB\nHQW\nHQB' )

            #ax1.set_xticklabels(lables)


            plt.legend(loc='best', markerscale=1)
            plt.tight_layout()
            plt.savefig('figures/action_by_kappa_0_initpairs_{}apps_{}kappa_{}c.pdf'.format(i,kappa, c))

            plt.show()
            plt.clf()
            plt.close('all')

        # the figure
        for kappa in np.arange(0.13,0.15,0.02):
            kappa = round(kappa, 2)

            c=0.000105
            c = round(round(c, 5) * 1000, 2)
            # print(c)

            if c >= 10:
                c_name = str(round(c / 10, 2)) + "00000e-02"
            elif (c < 10) & (c >= 1):
                # c_name = str(c) + "00000e-03"
                c_name = str(c) + "0000e-03"
            elif (c < 1) & (c >= 0.1):
                c_name = str(round(c * 10, 2)) + "00000e-04"
            elif (c < 0.1) & (c >= 0.01):
                c_name = str(round(c * 100, 2)) + "00000e-05"

            for i in range(1,9):
                # "new_policy_hist_simulated_beta_censored_norm_pairs0_w_x_8depth_0pairs_censored_norm_0_initpairs0_kappa0.01_c1.000000e-05"
                file_name_hist = "new_policy_hist_simulated_beta_censored_norm_pairs0_w_x_8depth_0pairs_censored_norm_{}_initpairs0_kappa{}_c{}".format(
                    i, kappa, c_name)

                df_hist = call_file_quality2(file_name_hist, i)


                df_hist['kappa'] = kappa
                df_hist['c'] = c
                df_hist['apps'] = i

                df_hist['name'] = "Kappa: " + df_hist['kappa'].astype(str) + "\n" + \
                                  "Sent: " + df_hist['hist_type_design'] + "\n" + \
                                  "CB: "  + df_hist['hist_type']

                df_hist['val_accuse'] = df_hist['posterior'] - kappa

                df_hist['V_b_l_final'] = None
                df_hist['V_w_l_final'] = None
                df_hist['V_b_h_final'] = None
                df_hist['V_w_h_final'] = None

                df_hist['V_w_l_final'].loc[df_hist['action']==1] = df_hist['V_w_l'][df_hist['action']==1]
                df_hist['V_b_l_final'].loc[df_hist['action']==2] = df_hist['V_b_l'][df_hist['action']==2]
                df_hist['V_w_h_final'].loc[df_hist['action']==3] = df_hist['V_w_h'][df_hist['action']==3]
                df_hist['V_b_h_final'].loc[df_hist['action']==4] = df_hist['V_b_h'][df_hist['action']==4]


                fig_qulity_by_apps_kappa(df_hist, i, kappa, c)


