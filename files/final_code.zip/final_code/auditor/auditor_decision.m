function save_results = auditor_decision(num_initial_pairs, max_depth, pairs, xbs,  params, data_set, prior_params, model)
% Tha auditor's decision
tic
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 1) Declare model      %%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    simulated_data = isequal(data_set,'simulated_beta_censored_norm_pairs0_w_x');
        
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 2) prior parameters   %%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    % parameters for high and low quality, corresponds to the quality index
    % being 1 SD above and below its mean
    if xbs>1
        prior_params(end) =  -0.5087;
        prior_params(end+1) = 0.5087;
    end

    % Declare number of covariate bins
    cov_params = prior_params(9:end);
    cov_bins = size(cov_params,2);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 3) import the data and standardize %%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%Pull in data;
    data_raw=csvread([data_set '.csv']);
    l=1;
    id=data_raw(:,l); % job id
    l=l+1; 
    if simulated_data==0 
        cluster=data_raw(:,l); l=l+1;
    end
    Y=data_raw(:,l); % callback
    l=l+1;
    D=data_raw(:,l); % black app
    l=l+1;

    if simulated_data==1
        data=[id Y D data_raw(:,4:end)];
        p_w_real = data(:,4);
        p_b_real = data(:,5);
    else
        data=[id Y D];
    end   

    % calculate the number of unique jobs
    if pairs==1 % if the auditor sends pairs and not single applications
        if xbs==1
            num_firms = length(data)/max_depth;
        elseif xbs>1
            num_firms = length(data)/(max_depth*4);
        end    
    elseif xbs==1
        num_firms = length(data)/(max_depth*2);
    elseif xbs>1
        num_firms = length(data)/(max_depth*2*xbs);
    end
    num_pairs = sum(D)/cov_bins/num_firms;
    
    % transform the data
    black_apps = D==1;
    white_apps = D==0;
    
    data_b = data(black_apps,:);
    data_w = data(white_apps,:);
    
    % acctual_draws dimensions: num_firms X  num_pairs X 2*cov_bins. the
    % third dimesion order is: white_low, black_low, white_high, black_high
    acctual_draws = zeros(num_firms,num_pairs,2*cov_bins);
    for k=1:cov_bins
        acctual_draws(:,:,1+2*(k-1)) = reshape(data_w(data_w(:,6)==k,2),[num_pairs, num_firms ])';
        acctual_draws(:,:,2+2*(k-1)) = reshape(data_b(data_b(:,6)==k,2),[num_pairs, num_firms ])';
    end
    
    % the columns of histories: n_w_l, R_w_l, n_b_l, R_b_l, n_w_h, R_w_h, n_b_h, R_b_h
    histories = zeros(num_firms,4*cov_bins);
    
    if cov_bins==1
        % if we don't have quality groups the numbe of initial black-white
        % pairs is num_initial_pairs
        k=1;
        N_start = num_initial_pairs;
        histories(:,1+4*(k-1)) = num_initial_pairs;
        histories(:,3+4*(k-1)) = num_initial_pairs;

        % Correct for chattering in application draws
        % white (first low second high)
        histories(:,2+4*(k-1)) = sum(acctual_draws(:,1:N_start,1+2*(k-1)),2) / num_initial_pairs;
        % black (first low second high)
        histories(:,4+4*(k-1)) = sum(acctual_draws(:,1:N_start,2+2*(k-1)),2) / num_initial_pairs;

    else
        % Otherwise we have to distribute initial pairs among types randomly
        choices_w = zeros(num_firms,cov_bins);
        choices_w(:,1) = randi([0 num_initial_pairs],num_firms,1);
        choices_b = zeros(num_firms,cov_bins);
        choices_b(:,1) = randi([0 num_initial_pairs],num_firms,1);
        for k = 2:cov_bins
            for j = 1:num_firms
                choices_w(j,k) = randi([0 (num_initial_pairs-sum(choices_w(j,1:k-1)))],1,1);
                choices_b(j,k) = randi([0 (num_initial_pairs-sum(choices_b(j,1:k-1)))],1,1);
            end
        end
        choices_w(:,end) = num_initial_pairs - sum(choices_w(:,1:cov_bins-1),2);
        choices_b(:,end) = num_initial_pairs - sum(choices_b(:,1:cov_bins-1),2);

        for k = 1:cov_bins
            histories(:,1+4*(k-1)) = choices_w(:,k);
            histories(:,3+4*(k-1)) = choices_b(:,k);

            for p = 1:num_initial_pairs
                % Correct for chattering in application draws
                histories(choices_w(:,k) == p,2+4*(k-1)) = sum(acctual_draws(choices_w(:,k) == p,1:p,1+2*(k-1)),2) / p;
                histories(choices_b(:,k) == p,4+4*(k-1)) = sum(acctual_draws(choices_b(:,k) == p,1:p,2+2*(k-1)),2) / p;
            end
        end        
    end % end of if cov_bin==1
    
    % Replace NaNs with zeros if needed
    histories(isnan(histories)) = 0;
    orig_histories = histories;

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%%% 4) The auditor's problem   %%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    % Reset histories
    histories = orig_histories;

    uni = unique(histories,'rows');
    % creates indicator for every firm and unique history
    indicators = zeros(num_firms,size(uni,1));
    for type = 1:size(uni,1)
        indicators(:,type) = sum(abs(histories - uni(type,:)),2) == 0;
    end

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% 4.1) initial evaluation using just the first histories %%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    value_dict = nan(0,4*cov_bins + 1       +1     + 1       +2*cov_bins); 
    % This dictionary stores history, recursion, max_val, choice , values_w_b
    % so total dim = 4*cov_bins + 1 + 2 +2*cov_bins
    
    % save policy dictionaries
    uniresults_dict = containers.Map();
    firmresults_dict = containers.Map();
    
    % unique histories
    uniresults = zeros(size(uni,1),   3+        2*cov_bins   +2*cov_bins);
    % uniresults = max_val, choice, posterioor, expected_Ps , values_w_b
    
    for row = 1:size(uni,1)
        % for every unique history calculate recursivly the optimal policy
        % and expected values
        [t, c, vd, posterior_save, ep_w, ep_b, prob_disc, vw_vb] = policy_singles(params, uni(row,:), prior_params, sum(uni(row,1:2:4*cov_bins)), max_depth, value_dict, model); 
        
        uniresults(row,:) = [t c posterior_save , ep_w, ep_b , vw_vb];
        value_dict = unique([value_dict ; vd], 'rows');
        
    end

    results = indicators*uniresults;
    
    uniresults_aux = [uni , uniresults];
    firm_results = indicators*uniresults_aux;
    if simulated_data==1   
        if xbs>1
            data_low_q = data(data(:,6)==1,:);
            data_high_q = data(data(:,6)==2,:);
            firm_results = [[1:num_firms]' firm_results data_low_q(1:max_depth*2:end,4:5) data_high_q(1:max_depth*2:end,4:5) data(1:max_depth*4:end,7) ];
        elseif xbs==1
            firm_results = [[1:num_firms]' firm_results data(1:max_depth*2:end,4:5) data(1:max_depth*2:end,7)];
        end    
    else
        firm_results = [[1:num_firms]' firm_results ];
    end
    
    uniresults_dict(num2str(num_initial_pairs)) = uniresults_aux;
    firmresults_dict(num2str(num_initial_pairs)) = firm_results;
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% 4.2) All next evaluations assuming immidiate callback  %%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    count_dict = num_initial_pairs;
    % If some firms should be sampled again, do so
    while sum(results(:,2) <= 2*cov_bins) > 0
        % Loop over the possibile responses
        for k = 1:cov_bins
            kc = 4*(k-1);

            % First the white choice
            ind = results(:,2) == 2*k-1;
            if sum(ind) > 0
                tograb = histories(ind,1+kc)+1; %% add one more white app
                draws_size = size(acctual_draws,2);
                selector = zeros(sum(ind),draws_size);
                
                for type = 1:draws_size
                    selector(:,type) = (tograb == type); % for every firm how many apps we have sent +1
                    % it tells us to which app number order are we are adding a call back 

                end
                toadd = sum(acctual_draws(ind,:,1+2*(k-1)).*selector,2); % the new call back data that should be added to history

                %add the new call back and the new app to the history
                histories(ind,2+kc) = (histories(ind,1+kc).*histories(ind,2+kc) + toadd) ./ (histories(ind,1+kc)+1);
                histories(ind,1+kc) = histories(ind,1+kc) + 1;
            end

            % Now for choices to send_black, with correction for pairs
            ind = results(:,2) == 2*k-pairs;
            if sum(ind) > 0
                tograb = histories(ind,3+kc)+1; %% add one more black app
                draws_size = size(acctual_draws,2);
                selector = zeros(sum(ind),draws_size);

                for type = 1:draws_size
                    selector(:,type) = (tograb == type); % for every firm # of apps sent +1
                    % it tells us to which app number order are we are adding a call back 
                end
                toadd = sum(acctual_draws(ind,:,2+2*(k-1)).*selector,2);
                histories(ind,4+kc) = (histories(ind,3+kc).*histories(ind,4+kc) + toadd) ./ (histories(ind,3+kc)+1);
                histories(ind,3+kc) = histories(ind,3+kc) + 1;
            end
        end	

        % Now go over the results again for everyone who wanted to resample
        ind = results(:,2) <= 2*cov_bins;
        uni = unique(histories(ind,:),'rows');
        indicators = zeros(num_firms,size(uni,1));
        for type = 1:size(uni,1)
            indicators(:,type) = sum(abs(histories - uni(type,:)),2) == 0;
        end

        uniresults = zeros(size(uni,1),   3+        2*cov_bins   +2*cov_bins);
        for row = 1:size(uni,1)
            
            [t, c, vd, posterior_save, ep_w, ep_b, prob_disc, vw_vb] = policy_singles(params, uni(row,:), prior_params, sum(uni(row,1:2:4*cov_bins)), max_depth, value_dict, model);
            
            uniresults(row,:) = [t c posterior_save, ep_w, ep_b, vw_vb];
            value_dict = unique([value_dict ; vd],'rows');

        end

        tmpresults = indicators*uniresults;

        results(ind,:) = tmpresults(ind,:);
        
        uniresults_aux = [uni , uniresults];
        firm_results = indicators*uniresults_aux;
   
        if  simulated_data==1
            if  xbs>1
                data_low_q = data(data(:,6)==1,:);
                data_high_q = data(data(:,6)==2,:);
                firm_results = [[1:num_firms]' firm_results data_low_q(1:max_depth*2:end,4:5) data_high_q(1:max_depth*2:end,4:5) data(1:max_depth*4:end,7) ];
            elseif xbs==1
                firm_results = [[1:num_firms]' firm_results data(1:max_depth*2:end,4:5) data(1:max_depth*2:end,7)];
            end    
        else
            firm_results = [[1:num_firms]' firm_results ];
        end    
        count_dict = count_dict+1;
        uniresults_dict(num2str(count_dict)) = uniresults_aux;
        firmresults_dict(num2str(count_dict)) = firm_results;       
    end % end of while loop

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%% 4) Output and some statistics %%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%    
    
    if  simulated_data==1

        % save policy results
        kappa = params(2);
        c = params(3);
        
        keys_dict = keys(uniresults_dict);
        keys_map = str2num(cell2mat(keys_dict(end))); 
        for policy= num_initial_pairs:keys_map
            if xbs==1
                outname = sprintf('results/policy/new_policy_hist_%s_%sdepth_%spairs_%s_%s_initpairs%s_kappa%s_c%s.csv', data_set, num2str(max_depth), num2str(pairs), model, num2str(policy), num2str(num_initial_pairs), num2str(kappa),c);
                fid = fopen(outname,'w');
                names = { 'N_w' 'R_w' 'N_b' 'R_b' 'V' 'action' 'posterior' 'E_pw' 'E_pb' 'V_w' 'V_b'  };
                fprintf(fid, ' %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s\n', names{1,:});
                fclose(fid);

                dlmwrite(outname, uniresults_dict(num2str(policy)), 'delimiter', ',', '-append');

                outname = sprintf('results/policy/new_policy_firms_%s_%sdepth_%spairs_%s_%s_initpairs%s_kappa%s_c%s.csv', data_set, num2str(max_depth), num2str(pairs), model, num2str(policy), num2str(num_initial_pairs), num2str(kappa),c);
                fid = fopen(outname,'w');
                names = { 'id' 'N_w' 'R_w' 'N_b' 'R_b' 'V' 'action' 'posterior' 'E_pw' 'E_pb' 'p_w' 'p_b' 'V_w' 'V_b' 'beta'  };
                fprintf(fid, '%s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s\n', names{1,:});
                fclose(fid);

                dlmwrite(outname, firmresults_dict(num2str(policy)), 'delimiter', ',', '-append');
            elseif xbs>1
                outname = sprintf('results/policy/new_policy_hist_%s_%sdepth_%spairs_%s_%s_initpairs%s_kappa%s_c%s.csv', data_set, num2str(max_depth), num2str(pairs), model, num2str(policy), num2str(num_initial_pairs), num2str(kappa),c);
                fid = fopen(outname,'w');
                names = { 'N_w_l' 'R_w_l' 'N_b_l' 'R_b_l' 'N_w_h' 'R_w_h' 'N_b_h' 'R_b_h' 'V' 'action' 'posterior' 'E_pw_l' 'E_pb_l' 'E_pw_h' 'E_pb_h' 'V_w_l' 'V_b_l' 'V_w_h' 'V_b_h'  };
                fprintf(fid, ' %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,%s,%s,%s,%s,%s,%s,%s\n', names{1,:});
                fclose(fid);

                dlmwrite(outname, uniresults_dict(num2str(policy)), 'delimiter', ',', '-append');

                outname = sprintf('results/policy/new_policy_firms_%s_%sdepth_%spairs_%s_%s_initpairs%s_kappa%s_c%s.csv', data_set, num2str(max_depth), num2str(pairs), model, num2str(policy), num2str(num_initial_pairs), num2str(kappa),c);
                fid = fopen(outname,'w');
                names = { 'id' 'N_w_l' 'R_w_l' 'N_b_l' 'R_b_l' 'N_w_h' 'R_w_h' 'N_b_h' 'R_b_h' 'V' 'action' 'posterior' 'E_pw_l' 'E_pb_l' 'E_pw_h' 'E_pb_h' 'V_w_l' 'V_b_l' 'V_w_h' 'V_b_h' 'p_w_l' 'p_b_l' 'p_w_h' 'p_b_h' 'beta'  };
                %names = { 'id' 'N_w' 'R_w' 'N_b' 'R_b' 'V' 'action' 'posterior' 'E_pw' 'E_pb' 'p_w' 'p_b' 'V_w' 'V_b'  };
                fprintf(fid, ' %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s, %s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n', names{1,:});
                fclose(fid);

                dlmwrite(outname, firmresults_dict(num2str(policy)), 'delimiter', ',', '-append');                
                
            end    
        end
        
        

        
    end

    
   
toc
end