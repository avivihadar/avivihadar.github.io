function [e_logit_beta ep_w ep_b posterior] = bayes_severity(sim, prior_params, history, model)
	% Function computes posterior moments based on normal distribution of alpha_j and discrete types for beta_j
	% sim -- dimension of grid for numerical evaluation of posterior
	% beta -- Fixed estimate of beta parameter for types model 
	% beta_share -- Prior for share of beta != 0 firms
	% prior_params -- parameters of alpha_j normal distribution for type1 and type2, and bet share parameters, respectively
	% history -- vector of previous trials (possibly empty) as [N_white rate_white N_black rate_black]
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 0) Declare model      %%%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    censored = isequal(model,'censored_norm');
    
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 1) Define a few variables based on the inputs %%
	%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
	mu1 = prior_params(1); 
	sigma1 = prior_params(2); 		% Note this should be the SD -- not variance
	mu2 = prior_params(3); 
	sigma2 = prior_params(4); 		% Note this should be the SD -- not variance, (can also be the same as type1)
	beta_0 = prior_params(5);
    sigma_beta = prior_params(6);
    rho = prior_params(7);
    beta_2 = prior_params(8);
	

	% These are the covariate bins 
	xbs = prior_params(9:end);
	num_xbs = size(xbs,2);
    
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%% 2) Compute posteriors      %%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
    %%%Sim draws;
    sims=zeros(sim,2);
    halt=net(haltonset(2,'Skip',10),sim);
    sims(:,1)=norminv(halt(:,1));
    sims(:,2)=norminv(halt(:,2));
    
    %%%Process random coefficients;
    z1=sims(:,1);
    z2=rho*sims(:,1) + sqrt(1-(rho^2))*sims(:,2);
    alpha=mu1+sigma1*z1;
    beta=beta_0 + sigma_beta*z2 + beta_2*(z2.^2);
    
    if censored == 1
        beta(beta<0) =0;
    end
    
	% Define matrix of pws (sims by dim(types))
	probs_w = zeros(sim,num_xbs);
	for c = 1:num_xbs
		probs_w(:,c) = (1 + exp(-alpha - xbs(c))).^-1;
	end

	% Now also define a matrix of pbs
	probs_b = zeros(sim,num_xbs);
	for c = 1:num_xbs
		probs_b(:,c) = (1 + exp(-alpha - xbs(c) + beta)).^-1;
	end


	% f(c_w,c_b|p_w,p_b)
	p_h_mu2 = prod(probs_w.^(history(1:4:4*num_xbs).*history(2:4:4*num_xbs)).*(1-probs_w).^(history(1:4:4*num_xbs).*(1-history(2:4:4*num_xbs))) ...
				.* probs_b.^(history(3:4:4*num_xbs).*history(4:4:4*num_xbs)).*(1-probs_b).^(history(3:4:4*num_xbs).*(1-history(4:4:4*num_xbs))),2);
	
    % f(c_w,c_b) = \int f(c_w,c_b|p_w,p_b)*g(p_w,p_b)
    tot_p = mean(p_h_mu2);
    
    bayes_weight = p_h_mu2/tot_p;
    
    % calculate expected p_w-p_b
    p_w_minus_pb = mean(probs_w - probs_b,2);

    e_logit_beta =  mean(p_w_minus_pb.*bayes_weight);
    
	%%% 2) Now save expected p_w and p_b from posterior (note that these are now vectors of dim(num covar types))
	%<> should check the dimession!! <>
    ep_w = mean(probs_w.*bayes_weight);	
	ep_b = mean(probs_b.*bayes_weight);
    
    
    %%% 3) get posterior probability for p_b/p_w <=0.8
    disc = (probs_b./probs_w)<=0.8;
    posterior = mean(p_h_mu2.*disc)/tot_p;

end
