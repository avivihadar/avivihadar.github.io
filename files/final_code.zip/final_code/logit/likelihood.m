function [Q] = likelihood(theta,data,sims,model,ncovs,indiv);

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% UNPACK ARGUMENTS %%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %%%%Data;
        l=1;
        id=data(:,l);
        J=length(unique(id));
        R=length(sims(1,:,1));

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% COMPUTE LIKELIHOOD %%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        logL_j=zeros(J,1);
        for j=1:J;
            data_j=data(id==j,:);
            sims_j=reshape(sims(j,:,:),[R 2]);
            logL_j(j)=log(likelihood_j(theta,data_j,sims_j,model,ncovs));
        end;
        if indiv==0;
            Q=-sum(logL_j);
        end;
        if indiv==1;
            Q=-logL_j;
        end;
 



            