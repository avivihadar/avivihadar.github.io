%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% This program estimates the mixed logit model        %%%
%%% for the paper "Adaptive Correspondence Experiments" %%%
%%% Avivi, Kline, Rose and Walters (2021)     %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% SET UP MATLAB %%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
       %%Basic setup;
       clear all;
       try;
           parpool(40);
       end;
        
       %%Optimization parameters;
       options_fmin=struct('Display','iter','MaxFunEvals',100000,'MaxIter',1000,'GradObj','off','LargeScale','off','UseParallel',false,'TolFun',1e-6);
       
        %%Set model parameters;
        
            %General parameters;
            rand_seed=120; 
            rng(rand_seed);
            data_set='nunley';
            R=2500;
                        
            %Logit specification;
            % Pssible models: 'censored_norm' and 'censored_norm_restrict'
            model='censored_norm';
            model
            covs=1;
            covs_interact=0;
            savename=[data_set '_' model '_covs' num2str(covs)  '.mat'];
            

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% IMPORT DATA %%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %%Pull in data;
        data_raw=csvread([data_set '.csv']);
        l=1;
        id=data_raw(:,l); l=l+1; 
        cluster=data_raw(:,l); l=l+1;
        Y=data_raw(:,l); l=l+1;
        D=data_raw(:,l); l=l+1;
        if isequal(data_set,'nunley')==1
            industry=data_raw(:,l); l=l+1;
        end
        X=data_raw(:,l:end);
        J=length(unique(id));
        N=length(Y);
        X=X - mean(X,1);
        X_D=zeros(N,0);
        if covs_interact==1
            X=X(:,1);
            X_D=X;
        end
        if covs~=1
            X=zeros(N,0);
            X_D=zeros(N,0);
        end
        ncovs=length(X(1,:));
        data=[id Y D X X_D];
        
         %%Construct job-level objects;
         N_B=dummyvar(id)'*D;
         N_W=dummyvar(id)'*(1-D);
         C_B=dummyvar(id)'*(Y.*D);
         C_W=dummyvar(id)'*(Y.*(1-D));
         data_job=[unique(id) N_B N_W C_B C_W];

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%%%% ESTIMATE LOGIT MODEL %%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


    %%%% esimate the logit  model
        %%%Starting values;
        nparams = 3 + length(X(1,:)) + length(X_D(1,:)) + isequal(model,'censored_norm_restrict') + 2*isequal(model,'censored_norm')  ;
        theta_0=randn(nparams,1);
        
        %%%Sim draws;
        sims=zeros(J,R,2);
        halt=net(haltonset(2,'Skip',10),J*R);
        sims(:,:,1)=norminv(reshape(halt(:,1),[R J])');
        sims(:,:,2)=norminv(reshape(halt(:,2),[R J])');
        
        %%%Compute estimates;
        tic
        theta_hat=fminunc(@(x)likelihood(x,data,sims,model,ncovs,0),theta_0,options_fmin);
        toc

        %%%%Process results;
        
            %Standard errors;
             [theta_hat Q_hat exitflag output G H]=fminunc(@(x)likelihood(x,data,sims,model,ncovs,0),theta_hat,options_fmin);
             [x,~,~,~,~,~,G] = lsqnonlin(@(x)likelihood(x,data,sims,model,ncovs,1),theta_hat,[],[],optimset('MaxIter',0,'TolFun',1000000000));
             meat=zeros(length(theta_hat),length(theta_hat));
             for j=1:length(unique(id));
                g=G(j,:)';
                meat=meat+(g*g');
             end
             V=inv(H)*meat*inv(H);
             SE=sqrt(diag(V));
             obj=-Q_hat;
               
            %%Display;
            [theta_0 theta_hat SE]
           
            %%Get gamma
            l = nparams - length(X(1,:));
            gamma = theta_hat(l+1:end);
            
            X_index = X*gamma;
            
            %%Save;
            results={theta_hat,SE,obj,H,V,model,covs,theta_0};
            save(savename,'results');

   
   
     
   