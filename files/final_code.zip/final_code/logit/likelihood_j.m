function [L] = likelihood_j(theta,data,sims,model,ncovs)

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% UNPACK ARGUMENTS %%%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

        %%%%Data;
         l=1;
         id=data(:,l); l=l+1;
         Y=data(:,l); l=l+1;
         D=data(:,l); l=l+1;
         X=data(:,l:(l+ncovs-1)); l=l+ncovs;
         X_D=data(:,l:end);
         N=length(Y);
         R=length(sims(:,1));
         %
        %%%Classify model being estimated;
        continuous = isequal(model,'censored_norm') +isequal(model,'censored_norm_restrict');
        restrict = isequal(model,'censored_norm_restrict');
        
        censored = isequal(model,'censored_norm_restrict') + isequal(model,'censored_norm');
        
        %%%%Parameters to be estimated;
        l=1;
        alpha_0=theta(l); l=l+1;
        sigma_alpha=exp(theta(l)); l=l+1;
        beta_0=theta(l); l=l+1;
        sigma_beta=0; rho=0; beta_2=0;
        if continuous==1
            logit = @(x) exp(x)/(1+exp(x));
            
            sigma_beta=exp(theta(l)); l=l+1;
        
            if restrict==0
                rho=(exp(2*theta(l))-1)/(exp(2*theta(l))+1); l=l+1;
            end            
        end
        
        gamma=theta(l:(l+ncovs-1)); l=l+ncovs;
        gamma_D=theta(l:end);
       

    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    %%%%% COMPUTE LIKELIHOOD %%%%%%%%%%%%%%%%
    %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
    
        %%%Process random coefficients;

        z1=sims(:,1);
        z2=rho*sims(:,1) + sqrt(1-(rho^2))*sims(:,2);
        alpha=alpha_0+sigma_alpha*z1;
        beta=beta_0 + sigma_beta*z2 + beta_2*(z2.^2);
        if censored==1
            beta(beta<0) = 0;
            
        end
        
        %%%Likelihood;
        Y_big=repmat(Y,[1 R]);
        beta_big=repmat(beta',[N 1]);
        beta_big = beta_big + (beta_big~=0).*(X_D*gamma_D);
        U_0 = repmat(alpha',[N 1])+repmat(X*gamma,[1 R]);
        U_1 = U_0 - repmat(D,[1 R]).*beta_big;
        Lambda_1 = 1./(1+exp(-U_1));
        L_1 = prod(Y_big.*Lambda_1 + (1-Y_big).*(1-Lambda_1),1)';
        L = mean(L_1);

        
        